/* *****************************************************************************
 *  Name:
 *  Date:
 *  Description:
 **************************************************************************** */

public class Outcast {

    // constructor takes a WordNet object
    public Outcast(WordNet wordnet) {

    }

    // given an array of WordNet nouns, return an outcast
    public String outcast(String[] nouns) {
        return null;
    }

    public static void main(String[] args)  {
        // see test client below
    }
}
