import java.util.Comparator;

public class Solver {    
    private static class SearchNode implements Comparable<SearchNode> {
        private final Board board;
        private final int moves;
        private final SearchNode previous;
        public SearchNode(Board board, int moves, SearchNode previous) {
            this.board = board;
            this.moves = moves;
            this.previous = previous;
        }  
        
        Iterable<Board> iterable() {
            SearchNode previous = this.previous;
            Stack<Board> boards = new Stack<Board>();
            boards.push(this.board);
            while (previous != null) {            
                boards.push(previous.board);
                previous = previous.previous;
            }
            return boards;
        }

        @Override
        public int compareTo(SearchNode that) {
            return moves + board.manhattan() - (that.moves + that.board.manhattan());
        } 
    }
    
    /*
    private static class HammingComparator implements Comparator<SearchNode> {
        @Override
        public int compare(SearchNode n1, SearchNode n2) {
            int h1 = n1.moves + n1.board.hamming();
            int h2 = n2.moves + n2.board.hamming();
            int cmp = h1 - h2;
            if (cmp == 0) cmp = manhattanCmp(n1, n2);
            return cmp;
        }

        private int manhattanCmp(SearchNode n1, SearchNode n2) {
            int h1 = n1.moves + n1.board.manhattan();
            int h2 = n2.moves + n2.board.manhattan();
            return h1 - h2;
        }        
    }*/
   
    private final MinPQ<SearchNode> nodes;
    private final MinPQ<SearchNode> twins;
    
    private final SearchNode initialNode;
    private SearchNode solution; 
    
    /**
     * Find a solution to the initial board (using the A* algorithm)
     * @param initial
     */
    public Solver(Board initial) {
        nodes = new MinPQ<Solver.SearchNode>(/*new HammingComparator()*/);
        twins = new MinPQ<Solver.SearchNode>(/*new HammingComparator()*/);
        initialNode = new SearchNode(initial, 0, null);             
        solution = null;
        
        nodes.insert(initialNode);
        twins.insert(new SearchNode(initial.twin(), 0, null));        
    }     
    
    /**
     * Is the initial board solvable?
     * @return true iff solvable
     */
    public boolean isSolvable()  {        
        if (initialNode.board.dimension() < 2) return false;
        if (initialNode.board.isGoal()) { 
            solution = initialNode;   
            return true;
        }
        if (solution != null) return true;
        
        while (true) {  
            SearchNode node = nodes.delMin();
            SearchNode twin = twins.delMin();
            
            if (node.board.isGoal()) {
                solution = node;
                return true;
            }
            
            if (twin.board.isGoal()) {
                return false;                
            }
            
            for (Board neignour: node.board.neighbors()) {
                if (alreadyPassed(neignour, node)) continue;
                nodes.insert(new SearchNode(neignour, node.moves + 1, node));
            }
            
            for (Board neignourTwin: twin.board.neighbors()) {
                if (alreadyPassed(neignourTwin, twin)) continue;
                twins.insert(new SearchNode(neignourTwin, twin.moves + 1, twin));
            }
        }
    }   

    /**
     * Min number of moves to solve initial board; -1 if unsolvable
     * @return min number of moves to solve initial board; -1 if unsolvable
     */
    public int moves() {
        if (solution == null && !isSolvable()) return -1;
        return solution.moves;
    } 
    
    /**
     * Sequence of boards in a shortest solution; null if unsolvable
     * @return solutions
     */
    public Iterable<Board> solution() {
        if (solution == null && !isSolvable()) return null;
        return solution.iterable();
    }   
    
    private boolean alreadyPassed(Board current, SearchNode parent) {
        if (parent.previous == null) return false;
        return current.equals(parent.previous.board);
    }
    
    public static void main(String[] args) {
        // create initial board from file
        In in = new In(args[0]);
        int N = in.readInt();
        int[][] blocks = new int[N][N];
        for (int i = 0; i < N; i++)
            for (int j = 0; j < N; j++)
                blocks[i][j] = in.readInt();
        Board initial = new Board(blocks);

        // solve the puzzle
        Solver solver = new Solver(initial);

        // print solution to standard output
        if (!solver.isSolvable())
            StdOut.println("No solution possible");
        else {
            StdOut.println("Minimum number of moves = " + solver.moves());
            for (Board board : solver.solution())
                StdOut.println(board);
        }
    }
}